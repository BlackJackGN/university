import socket,struct,sys,time
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    ip_str = sys.argv[1] #Leggi gli argomenti. sys.argv[0] è il nome dello script, quindi [1] e [2] sono i tuoi due parametri.
    port = int(sys.argv[2]) #La porta va convertita in intero per essere usata come numero di porta.

    ip_bytes = socket.inet_aton(ip_str) #Conversione della stringa IP in 4 byte.
    ip_uint = struct.unpack("!I", ip_bytes)[0] #Unpacking dei 4 byte in un intero senza segno a 32 bit (big-endian).
    print(f"IP is {socket.inet_ntoa(ip_bytes)}; uint_32 is {ip_uint}")
    print(f"Port is {port}; uint16 is {port}")

    payload=ip_bytes+b"\0"+struct.pack("!H", port)+b"\0" #Payload: 4 byte IP + 1 byte null + 2 byte port + 1 byte null separatore.
    
    s.connect(('localhost', 1025)) #Connessione al server TCP su localhost:1025 (Inserire ip e porta del server)
    s.sendall(payload) #Invio del payload al server

    data = s.recv(1024) #Ricezione della risposta dal server
    hostname = data.split(b" ")[-1]
    print(f"Received hostname: {hostname.decode()}")

    """Specchietto metodi utilizzati:
    socket.socket() - crea un nuovo socket
    socket.connect() - connette il socket a un server
    socket.sendall() - invia dati al server
    socket.recv() - riceve dati dal server
    socket.inet_aton() - converte un indirizzo IP in formato stringa in 4 byte
    socket.inet_ntoa() - converte un indirizzo IP in formato 4 byte in stringa
    struct.pack() - converte un intero in byte secondo un formato specificato"""