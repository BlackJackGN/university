import socket
import sys
import time
HOST = 'localhost'
PORT = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    print(f"Server listening on {HOST}:{PORT}")
    conn, addr = s.accept()
    data = conn.recv(1024)
    print(f"Received data: {data.decode()}")
    #sending hostname to client
    conn.sendall(b"Welcome from "+socket.gethostname().encode())
    time.sleep(1)