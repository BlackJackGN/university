import socket,struct,sys,time
host = 'localhost' #Inizializzazione server TCP su localhost:1025
port = 1025
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    #Creazione socket. AF_INET = IPv4; SOCK_STREAM = TCP. 
    #Il with è un context manager: garantisce che il socket si chiuda a fine blocco, anche se c'è un errore.
    #È il modo pulito per non dimenticare la close()

    s.bind((host, port)) #Collegamento del socket all'indirizzo e porta specificati.
    s.listen() #Ascolto del socket su indirizzo e porta specificati.

    conn, addr = s.accept() #Connessione in entrata accettata. Ritorna un nuovo socket conn e l'indirizzo del client addr.
    data = conn.recv(1024) #Ricezione dei dati dal client. 1024 è la dimensione massima del buffer di ricezione.
    ip_bytes = data[:4] #Estrazione dei primi 4 byte (IP address) dal payload ricevuto
    port_bytes = data[5:7] #Estrazione dei byte 5 e 6 (port number) dal payload ricevuto
    ip_uint = struct.unpack("!I", ip_bytes)[0] #Unpacking dei 4 byte in un intero senza segno a 32 bit (big-endian).
    port_uint = struct.unpack("!H", port_bytes)[0] #Unpacking dei 2 byte in un intero senza segno a 16 bit (big-endian).
    print(f"Received IP: {socket.inet_ntoa(ip_bytes)}; uint_32 is {ip_uint}")

    conn.sendall(b"Welcome from "+socket.gethostname().encode()) #Invio della risposta al client con hostname del server.
    
    """Specchietto metodi utilizzati:
    socket.socket() - crea un nuovo socket
    socket.bind() - associa il socket a un indirizzo e porta
    socket.listen() - mette il socket in ascolto per connessioni in entrata
    socket.accept() - accetta una connessione in entrata e ritorna un nuovo socket e l'indirizzo del client
    socket.recv() - riceve dati dal client
    socket.sendall() - invia dati al client
    socket.gethostname() - ritorna il nome host del server
    socket.inet_ntoa() - converte un indirizzo IP in formato 4 byte in stringa
    struct.unpack() - converte byte in un intero secondo un formato specificato"""