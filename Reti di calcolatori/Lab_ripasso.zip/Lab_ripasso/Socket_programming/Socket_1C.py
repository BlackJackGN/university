import socket
import sys
import time
HOST = 'localhost'
PORT = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    s.sendall(b"Hello, server!\n")
    s.sendall(sys.argv[2].encode())
    data = s.recv(1024).decode()
    data = data.split("Welcome from ")
    print(f"Server name: {data[1]}")