import socket,struct,sys,time,os
host = sys.argv[1]
port = int(sys.argv[2])
file = sys.argv[3:] #Selezione dei file da inviare, si prendono tutti a partire dal 3

def build_header_ar(fname, fsize):
    #Metodo per costruire l'header formato ar del pacchetto da inviare, con nome e dimensione del file
    name_field=(os.path.basename(fname)+"/")[:16].ljust(16) #Nome del file, massimo 16 caratteri, con padding di spazi
    mtime_field="0".ljust(12) #Timestamp del file, massimo 12 caratteri, con padding di spazi
    uid_field="0".ljust(6) #UID del file, massimo 6 caratteri, con padding di spazi
    gid_field="0".ljust(6) #GID del file, massimo 6 caratteri, con padding di spazi
    mode_field="644".ljust(8) #Permessi del file, massimo 8 caratteri, con padding di spazi
    size_field=str(fsize).ljust(10) #Dimensione del file, massimo 10 caratteri, con padding di spazi
    return (name_field+mtime_field+uid_field+gid_field+mode_field+size_field).encode('utf-8')+b'`\n'

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((host, port))
    s.sendall(b'!<arch>\n') #Invio della signature del formato ar
    for f in file:
        data = open(f, 'rb').read() #Apertura del file in lettura binaria
        size = len(data)
        s.sendall(build_header_ar(f, size)) #Invio dell'header del file
        s.sendall(data) #Invio del file
        if size % 2 == 1: #Se il file ha dimensione dispari, invio un byte di padding        
            s.sendall(b"\n")

    """Specchietto metodi usati/aggiunti:
    - build_header_ar(fname, fsize): 
        Metodo per costruire l'header formato ar del pacchetto da inviare, con nome e dimensione del file
    - s.sendall(b'!<arch>\n'):
        Invio della signature del formato ar al server"""        