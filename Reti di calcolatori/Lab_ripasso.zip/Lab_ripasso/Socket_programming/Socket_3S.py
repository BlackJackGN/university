import socket,struct,sys,time
host = sys.argv[1]
port = int(sys.argv[2])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((host, port))
    s.listen()
    conn, addr = s.accept()
    with open("ricevuto.a", "wb") as out:
        with conn:
            while True:
                data = conn.recv(4096) #Ricezione dei dati dal client
                if not data:
                    break
                out.write(data)
    
    """Specchietto metodi usati/aggiunti:
    - out.write(data):
        Scrittura dei dati ricevuti nel file di output "ricevuto.a" in modalità binaria"""