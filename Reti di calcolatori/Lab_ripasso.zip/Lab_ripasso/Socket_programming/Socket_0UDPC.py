import socket
import sys
import time
HOST = 'localhost'
PORT = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    #write to server via UDP
    s.sendto(b'Hello, UDP server!\n'+sys.argv[2].encode(), (HOST, PORT))