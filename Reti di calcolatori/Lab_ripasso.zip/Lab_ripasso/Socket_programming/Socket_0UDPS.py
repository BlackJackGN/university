import socket
import sys
import time
HOST = 'localhost'
PORT = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    s.bind((HOST, PORT))
    data, addr = s.recvfrom(1024)
    print('Received message:', data.decode())