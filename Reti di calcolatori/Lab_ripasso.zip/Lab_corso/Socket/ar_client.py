#!/usr/bin/env python3

import socket
import sys
import os

def create_header(filename):
    """Creates the 60-byte ar header for a given file."""
    try:
        # Get file stats
        st = os.stat(filename)
        name = (filename[:15] + "/").ljust(16) # Name: 16 bytes, left-aligned, space-padded, ending in /
        # Meta: Timestamp(12), UID(6), GID(6), Mode(8), Size(10)
        mtime = "0".ljust(12)
        uid   = "0".ljust(6)
        gid   = "0".ljust(6)
        mode  = "644".ljust(8)
        size  = str(st.st_size).ljust(10)
        terminator = "`\n"
        
        # Combine into 60-byte string and encode to bytes
        header_str = f"{name}{mtime}{uid}{gid}{mode}{size}{terminator}"
        return header_str.encode('ascii')
    except OSError as e:
        print(f"Error accessing {filename}: {e}")
        return None

def main():
    if len(sys.argv) < 4:
        print(f"Usage: {sys.argv[0]} <server_ip> <port> <file1> [<file2> ...]")
        sys.exit(1)

    server_ip = sys.argv[1]
    port = int(sys.argv[2])
    files = sys.argv[3:]
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((server_ip, port))
            s.sendall(b"!<arch>\n") # Seng Archive Global Header
            for filename in files:
                header = create_header(filename)
                if header is None:
                    continue
                # Send Header
                s.sendall(header)
                # Send File Content (in chunks for performance)
                with open(filename, "rb") as f:
                    while True:
                        chunk = f.read(4096)
                        if not chunk:
                            break
                        s.sendall(chunk)
                # Padding (if file size is odd)
                if os.path.getsize(filename) % 2 != 0:
                    s.sendall(b"\n")
    except ConnectionRefusedError:
        print("Error: Could not connect to the server.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
