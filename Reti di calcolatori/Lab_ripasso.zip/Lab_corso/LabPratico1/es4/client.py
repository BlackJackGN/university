#!/usr/bin/env python3
import socket
import sys
import os
HOST = sys.argv[1]
PORT = int(sys.argv[2])
files = sys.argv[3:]  # tutti i file dalla terza posizione in poi

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    s.send(b'!<arch>\n')
    for filename in files:
        nome = (filename + '/').ljust(16)  # 16 byte
        timestamp = '0'.ljust(12)  # 12 byte
        uid = '0'.ljust(6)  # 6 byte
        gid = '0'.ljust(6)  # 6 byte
        permessi = '644'.ljust(8)  # 8 byte
        dimensione = str(os.path.getsize(filename)).ljust(10)  # 10 byte
        terminatore = '\x60\n'  # 2 byte

        header = (nome + timestamp + uid + gid + permessi + dimensione + terminatore).encode()
        with open(filename, 'rb') as f:
            contenuto = f.read()
            s.send(header)
            s.send(contenuto)
        if len(contenuto) % 2 != 0:
            s.send(b'\n')