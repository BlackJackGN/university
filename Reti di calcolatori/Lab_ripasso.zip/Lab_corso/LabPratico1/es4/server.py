#!/usr/bin/env python3
import socket
import sys
HOST = '127.0.0.1'
PORT = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    conn, addr = s.accept()
    data = b''
    while True:
        chunk = conn.recv(1024)
        if not chunk:  # il client ha chiuso la connessione
            break
        data += chunk
    print(f'Ricevuti {len(data)} byte')
    print(data.hex())