#!/usr/bin/env python3
import socket
import sys

HOST = '127.0.0.1'
PORT = int(sys.argv[1])

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    s.bind((HOST, PORT))
    while True:
        data, addr = s.recvfrom(1024)
        print('Here is the message: %s' % data.decode('utf-8'))
        if data.decode('utf-8') == 'exit':
            break
        s.sendto('I got your message'.encode('utf-8'), addr)