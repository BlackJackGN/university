#!/usr/bin/env python3
import socket
import sys
import struct
HOST = '127.0.0.1'
PORT = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()
    conn, addr = s.accept()
    data = conn.recv(1024)
    ip_bytes=data[0:4]
    port_bytes=data[4:6]
    ip_int=struct.unpack('!I',ip_bytes)[0]
    port_int=struct.unpack('!H',port_bytes)[0]
    print(f'IP is {socket.inet_ntoa(ip_bytes)}; uint32 is {ip_int}')
    print(f'Port is {port_int}; uint16 is {port_int}')
    conn.close()