#!/usr/bin/env python3
import socket
import sys
import struct
HOST = sys.argv[1]
PORT = int(sys.argv[2])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    ip_bytes=socket.inet_aton(HOST)
    port_bytes=struct.pack('!H', PORT)#(big endian)
    ip_int = struct.unpack('!I', ip_bytes)[0]
    print(f'IP is {HOST}; uint32 is {ip_int}')
    print(f'Port is {PORT}; uint16 is {PORT}')
    s.send(ip_bytes+port_bytes)