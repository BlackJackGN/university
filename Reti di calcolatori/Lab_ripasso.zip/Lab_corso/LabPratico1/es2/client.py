#!/usr/bin/env python3
import socket
import sys
HOST = '127.0.0.1'
PORT = sys.argv[1]
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, int(PORT)))
    data = s.recv(1024).decode('utf-8')
    hostname = data.split('Welcome from ')[1].replace('!', '')
    print(f'Hostname is: {hostname}')