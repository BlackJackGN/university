#!/usr/bin/env python3
import socket
import sys

HOST = '127.0.0.1'
PORT = sys.argv[1]

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    hostname = socket.gethostname()
    s.bind((HOST, int(PORT)))
    s.listen()
    conn, addr = s.accept()
    msg = f'Welcome from {hostname}!'
    conn.sendall(msg.encode('utf-8'))
    conn.close()