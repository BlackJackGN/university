import numpy as np
from numpy.linalg import norm

eps = np.finfo(float).eps

def linear_kernel(x1, x2):
    return x1 @ x2

def polynomial_kernel(x1, x2, degree=3):
    return (x1 @ x2 + 1) ** degree

def rbf_kernel(x1, x2, gamma=0.01):
    return np.exp(-gamma * norm(x1 - x2)**2)

def compute_kernel_matrix(X1, X2, kernel_func, **kwargs):
    if kernel_func == linear_kernel:
        return X1 @ X2.T
    
    elif kernel_func == polynomial_kernel:
        degree = kwargs.get('degree', 3)
        return (X1 @ X2.T + 1) ** degree
    
    elif kernel_func == rbf_kernel:
        gamma = kwargs.get('gamma', 0.01)
        # ||x1 - x2||^2 = ||x1||^2 + ||x2||^2 - 2*x1@x2.T
        X1_sq = np.sum(X1**2, axis=1, keepdims=True)  # (n1, 1)
        X2_sq = np.sum(X2**2, axis=1, keepdims=True)  # (n2, 1)
        sq_dists = X1_sq + X2_sq.T - 2 * (X1 @ X2.T)  # (n1, n2)
        return np.exp(-gamma * sq_dists)
    
    else:
        # fallback con doppio loop per kernel custom
        n = X.shape[0]
        K = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                K[i, j] = kernel_func(X[i], X[j])
        return K

class SVM:
    """ Models a Support Vector machine classifier based on the PEGASOS algorithm. """

    def __init__(self, n_epochs, lambDa, use_bias=True):
        """ Constructor method """

        # weights placeholder
        self._w = None
        self._original_labels = None
        self._n_epochs = n_epochs
        self._lambda = lambDa
        self._use_bias = use_bias

    def map_y_to_minus_one_plus_one(self, y):
        """
        Map binary class labels y to -1 and 1
        """
        ynew = np.array(y)
        self._original_labels = np.unique(ynew)
        assert len(self._original_labels) == 2
        ynew[ynew == self._original_labels[0]] = -1.0
        ynew[ynew == self._original_labels[1]] = 1.0
        return ynew

    def map_y_to_original_values(self, y):
        ynew = np.array(y)
        ynew[ynew == -1.0] = self._original_labels[0]
        ynew[ynew == 1.0] = self._original_labels[1]
        return ynew

    def loss(self, y_true, y_pred):
        #return np.mean(np.maximum(0, 1 - y_true * y_pred))
        hinge = np.maximum(0.0, 1.0 - y_true * y_pred)
        return (self._lambda / 2.0) * np.dot(self._w, self._w) + np.mean(hinge)

    def fit_gd(self, X, Y, verbose=False):
        X = np.array(X, dtype=float)
        if self._use_bias:
            # integra il bias come colonna di 1: b = ultima componente di w
            X = np.hstack([X, np.ones((X.shape[0], 1))])
        y = self.map_y_to_minus_one_plus_one(Y)
        n_samples, n_features = X.shape

        self._w = np.zeros(n_features)
        rng = np.random.default_rng()
        t = 0
        for epoch in range(self._n_epochs):
            for _ in range(n_samples):
                t += 1
                i = rng.integers(n_samples)
                eta = 1.0 / (self._lambda * t)
                if y[i] * np.dot(self._w, X[i]) < 1.0:
                    self._w = (1.0 - eta * self._lambda) * self._w + eta * y[i] * X[i]
                else:
                    self._w = (1.0 - eta * self._lambda) * self._w
            if verbose:
                print(f"epoch {epoch + 1}/{self._n_epochs} - loss: {self.loss(y, X @ self._w):.6f}")
        return self

    def fit_kernel(self, X, Y, kernel_func, verbose=False):
        n_samples = X.shape[0]
        Y = self.map_y_to_minus_one_plus_one(Y)
        self._Y_train = Y
        
        # salva X e kernel per dopo (servono in predict)
        self._X_train = X
        self._kernel_func = kernel_func
        
        # inizializza alpha
        self._alpha = np.zeros(n_samples)
        
        # pre-calcola la matrice kernel
        K = compute_kernel_matrix(X, X, kernel_func)
        
        t = 0
        for e in range(1, self._n_epochs + 1):
            indices = np.random.permutation(n_samples)
            for j in indices:
                t += 1
                eta = 1.0 / (self._lambda * t)

                score = np.sum(self._alpha * Y * K[:, j])

                # prima regolarizzi
                self._alpha *= (1 - eta * self._lambda)
        
                # poi aggiorni se necessario
                if Y[j] * score < 1:
                    self._alpha[j] += eta

    def predict(self, X):
        X = np.array(X, dtype=float)
        if self._use_bias:
            X = np.hstack([X, np.ones((X.shape[0], 1))])
        y_pred = np.where(X @ self._w >= 0.0, 1.0, -1.0)
        return self.map_y_to_original_values(y_pred)

    def predict_kernel(self, X):
        K_test = compute_kernel_matrix(X, self._X_train, self._kernel_func)
        scores = K_test @ (self._alpha * self._Y_train)
        return self.map_y_to_original_values(np.sign(scores))
