import numpy as np

from datasets import gaussians_dataset, people_dataset

from utils import people_visualization
from utils import people_visualize_prediction
from utils import plot_pegasos_margin

from svm import SVM, rbf_kernel

#np.random.seed(191090)

def main_people():
    """ Main function """

    #x_train, y_train, x_test, y_test = gaussians_dataset(2, [100, 150], [[1, 3], [-4, 8]], [[2, 3], [4, 1]])
    #X_img_train, x_train, y_train, X_img_test, x_test, y_test = people_dataset('data')

    #from sklearn.preprocessing import StandardScaler
    #scaler = StandardScaler()
    #x_train = scaler.fit_transform(x_train)
    #x_test = scaler.transform(x_test)  # usa la media/std del train!

    #people_visualization(X_img_train, y_train)

    #svm_alg = SVM(n_epochs=200, lambDa= 0.0005, use_bias=False)
    #iperparametri migliori primale people: 500, 0.0005, 84.6%
    #iperparametri migliori duale people: 200, 0,0005, 94,2%

    # train
    #svm_alg.fit_gd(x_train, y_train, verbose=True)
    #svm_alg.fit_kernel(x_train, y_train, kernel_func=rbf_kernel, verbose=True)

    # test
    #predictions = svm_alg.predict_kernel(x_test)
    #predictions = svm_alg.predict_kernel(x_test)

    #accuracy = float(np.sum(predictions == y_test)) / y_test.shape[0]
    #print('Test accuracy: {}'.format(accuracy))

    #people_visualize_prediction(X_img_test, y_test, predictions)

def main_gaussian():

    x_train, y_train, x_test, y_test = gaussians_dataset(2, [100, 150], [[1, 3], [-4, 8]], [[2, 3], [4, 1]])

    svm_alg = SVM(n_epochs=500, lambDa= 0.005, use_bias=True)
    #iperparametri migliori primale gaussiano: 500, 0.005, 100%
    #iperparametri migliori duale gaussiano: 200, 0.001, 100%

    # train
    svm_alg.fit_gd(x_train, y_train, verbose=True)
    #svm_alg.fit_kernel(x_train, y_train, kernel_func=rbf_kernel, verbose=True)

    # test
    predictions = svm_alg.predict(x_test)
    #predictions = svm_alg.predict_kernel(x_test)

    accuracy = float(np.sum(predictions == y_test)) / y_test.shape[0]
    print('Test accuracy: {}'.format(accuracy))

    plot_pegasos_margin(x_test, y_test, svm_alg)#cambiare il plot nell'Utils.py

# entry point
if __name__ == '__main__':
    main_gaussian()
    #main_people()
