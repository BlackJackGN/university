import numpy as np
from sklearn.cluster import KMeans

def spectral_clustering(data, n_cl, sigma=1., fiedler_solution=False):
    S=np.exp(-sigma*np.sum((data[:,None,:]-data[None,:,:])**2, axis=-1))
    np.fill_diagonal(S, 0)
    D=np.diag(S.sum(axis=1))
    L=D-S
    eigvals, eigvecs = np.linalg.eigh(L)
    if fiedler_solution:
        return eigvecs[:, 1:n_cl+1]>0
    else:
        kmeans = KMeans(n_clusters=n_cl, n_init=10).fit_predict(eigvecs[:, 1:n_cl+1])
        return kmeans.labels_