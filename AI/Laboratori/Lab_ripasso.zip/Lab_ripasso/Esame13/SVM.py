import numpy as np

class SVM:

    def __init__(self, n_epochs, lambDa, use_bias=True):
        self._n_epochs = n_epochs
        self._lambda = lambDa
        self._use_bias = use_bias
        self._w = None
        self._original_labels = None

    def map_y_to_minus_one_plus_one(self, y):
        ynew = np.array(y, dtype=float)
        self._original_labels = np.unique(ynew)
        ynew[ynew == self._original_labels[0]] = -1.0
        ynew[ynew == self._original_labels[1]] = 1.0
        return ynew

    def map_y_to_original_values(self, y):
        ynew = np.array(y, dtype=float)
        ynew[ynew == -1.0] = self._original_labels[0]
        ynew[ynew == 1.0] = self._original_labels[1]
        return ynew

    def loss(self, y_true, y_pred):
        return 0.5 * self._lambda * np.linalg.norm(self._w)**2 \
               + np.mean(np.maximum(0, 1 - y_true * y_pred))

    def fit_gd(self, X, Y, verbose=False):
        Y = self.map_y_to_minus_one_plus_one(Y)
        if self._use_bias:
            X = np.concatenate([X, np.ones((X.shape[0], 1))], axis=-1)
        n_samples, n_features = X.shape
        self._w = np.zeros(n_features)

        eta_0 = 0.1
        t = 1  # global step, starts at 1 to avoid division by zero

        for epoch in range(self._n_epochs):
            indices = np.random.permutation(n_samples)
            for i in indices:
                eta_t = 1.0 / (self._lambda * t)
                xi, yi = X[i], Y[i]
                if yi * (xi @ self._w) < 1:
                    dw = self._lambda * self._w - yi * xi
                else:
                    dw = self._lambda * self._w
                self._w -= eta_t * dw
                t += 1

            if verbose and epoch % 10 == 0:
                y_pred = X @ self._w
                print(f'Epoch {epoch}, Loss: {self.loss(Y, y_pred)}')

    def predict(self, X):
        if self._use_bias:
            X = np.concatenate([X, np.ones((X.shape[0], 1))], axis=-1)
        return self.map_y_to_original_values(np.sign(X @ self._w))