import numpy as np

class KMeans:

    def __init__(self, n_cl, n_init=1):
        self.n_cl = n_cl
        self.n_init = n_init

    def _init_centers(self, X):
        n_samples, dim = X.shape
        centers = np.zeros((self.n_cl, dim))
        for i in range(dim):
            centers[:, i] = np.random.uniform(
                low=np.min(X[:, i]),
                high=np.max(X[:, i]),
                size=self.n_cl
            )
        return centers

    def single_fit_predict(self, X):
        n_samples, dim = X.shape
        centers = self._init_centers(X)
        old_assignments = np.zeros(n_samples)

        while True:
            # 1. assegna ogni punto al centro più vicino
            distances = np.linalg.norm(X[:, np.newaxis, :] - centers[np.newaxis, :, :], axis=2)
            assignments = np.argmin(distances, axis=1)

            # 2. aggiorna i centri
            for k in range(self.n_cl):
                if np.any(assignments == k):
                    centers[k] = X[assignments == k].mean(axis=0)

            # 3. controlla convergenza
            if np.array_equal(assignments, old_assignments):
                break
            old_assignments = assignments
        return centers, assignments        

    def compute_cost_function(self, X, centers, assignments):
        return np.sum(np.linalg.norm(X - centers[assignments], axis=1)**2)