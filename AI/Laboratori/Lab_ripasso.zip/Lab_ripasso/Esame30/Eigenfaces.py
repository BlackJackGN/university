import numpy as np

class Eigenfaces:

    def __init__(self, n_components):
        self.n_components = n_components
        self._x_mean = None
        self._ef = None

    def fit(self, X):
        # X shape: (n_samples, w*h)
        self._x_mean = X.mean(axis=0)
        A = X - self._x_mean                      # (m, n)

        # eigentrick: lavora su A A^T (m×m) invece di A^T A (n×n)
        C = A @ A.T                               # (m, m)
        eigenvalues, eigenvectors = np.linalg.eigh(C)

        # ordina per eigenvalue decrescente
        idx = np.argsort(eigenvalues)[::-1]
        eigenvectors = eigenvectors[:, idx]       # (m, m)

        # proietta indietro nello spazio pixel e normalizza
        # se v è autovettore di A A^T, allora A^T v è autovettore di A^T A
        ef = A.T @ eigenvectors                   # (n, m)
        ef = ef / np.linalg.norm(ef, axis=0)      # normalizza ogni colonna

        self._ef = ef[:, :self.n_components]      # (n, n_components)

    def transform(self, X):
        return (X - self._x_mean) @ self._ef      # (n_samples, n_components)

    def reconstruct(self, X):
        coords = self.transform(X)                # (n_samples, n_components)
        return self._x_mean + coords @ self._ef.T  # (n_samples, n)