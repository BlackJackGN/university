import numpy as np

class Eigenfaces:

    def __init__(self, n_components):
        self.n_components = n_components
        self._x_mean = None
        self._ef = None

    def fit(self, X):
        # X shape: (n_samples, w*h)
        self._x_mean = X.mean(axis=0)
        A = X - self._x_mean  # (n_samples, n_features)

        # Eigen trick (Turk & Pentland): decompose the small (m x m) matrix
        # L = A @ A.T instead of the huge (n_features x n_features) covariance.
        # If v is an eigenvector of L, then A.T @ v is an eigenvector of A.T @ A.
        L = A @ A.T                                      # (m, m)
        eigenvalues, eigenvectors = np.linalg.eigh(L)   # eigenvectors: (m, m)

        idx = np.argsort(eigenvalues)[::-1]              # descending order
        eigenvectors = eigenvectors[:, idx]

        # Project back to image space and normalise
        eigenfaces = A.T @ eigenvectors                  # (n_features, m)
        norms = np.linalg.norm(eigenfaces, axis=0, keepdims=True)
        eigenfaces /= norms

        self._ef = eigenfaces[:, :self.n_components]     # (n_features, k)

    def transform(self, X):
        return (X - self._x_mean) @ self._ef

    def inverse_transform(self, X):
        return X @ self._ef.T + self._x_mean