import numpy as np

class SVM:

    def __init__(self, n_epochs, lambDa, lr=0.01, use_bias=True):
        self._n_epochs = n_epochs
        self._lambda = lambDa
        self._lr = lr
        self._use_bias = use_bias
        self._w = None
        self._original_labels = None

    def map_y_to_minus_one_plus_one(self, y):
        ynew = np.array(y, dtype=float)
        self._original_labels = np.unique(ynew)
        ynew[ynew == self._original_labels[0]] = -1.0
        ynew[ynew == self._original_labels[1]] = 1.0
        return ynew

    def map_y_to_original_values(self, y):
        ynew = np.array(y, dtype=float)
        ynew[ynew == -1.0] = self._original_labels[0]
        ynew[ynew == 1.0] = self._original_labels[1]
        return ynew

    def loss(self, y_true, y_pred):
        return 0.5 * self._lambda * np.linalg.norm(self._w)**2 \
               + np.mean(np.maximum(0, 1 - y_true * y_pred))

    def fit_gd(self, X, Y, verbose=False):
        # 1. bias e label
        if self._use_bias:
            X = np.concatenate([X, np.ones((X.shape[0], 1))], axis=-1)
        
        n_samples, n_features = X.shape
        Y = self.map_y_to_minus_one_plus_one(Y)
        
        # 2. inizializzazione a zero
        self._w = np.zeros(n_features)
        
        # 3. t globale — non si azzera mai
        t = 0
        
        for e in range(1, self._n_epochs + 1):
            # 4. ordine casuale ad ogni epoca (SGD)
            indices = np.random.permutation(n_samples)
            
            for j in indices:
                t += 1
                # 5. learning rate adattivo — decresce continuamente
                eta = 1.0 / (self._lambda * t)
                
                # 6. check hinge loss
                if Y[j] * (self._w @ X[j]) < 1:
                    # regolarizzazione + correzione gradiente
                    self._w = (1 - eta * self._lambda) * self._w + eta * Y[j] * X[j]
                else:
                    # solo regolarizzazione
                    self._w = (1 - eta * self._lambda) * self._w
            
            if verbose:
                y_pred = X @ self._w
                print(f"Epoch {e}: loss={self.loss(Y, y_pred):.4f}")

    def predict(self, X):
        if self._use_bias:
            X = np.concatenate([X, np.ones((X.shape[0], 1))], axis=-1)
        return self.map_y_to_original_values(np.sign(X @ self._w))