import numpy as np

class SVM:

    def __init__(self, n_epochs, lambDa, use_bias=True):
        self._n_epochs = n_epochs
        self._lambda = lambDa
        self._use_bias = use_bias
        self._w = None
        self._original_labels = None

    def map_y_to_minus_one_plus_one(self, y):
        ynew = np.array(y, dtype=float)
        self._original_labels = np.unique(ynew)
        ynew[ynew == self._original_labels[0]] = -1.0
        ynew[ynew == self._original_labels[1]] = 1.0
        return ynew

    def map_y_to_original_values(self, y):
        ynew = np.array(y, dtype=float)
        ynew[ynew == -1.0] = self._original_labels[0]
        ynew[ynew == 1.0] = self._original_labels[1]
        return ynew

    def loss(self, y_true, y_pred):
        return 0.5 * self._lambda * np.linalg.norm(self._w)**2 \
               + np.mean(np.maximum(0, 1 - y_true * y_pred))

    def fit_gd(self, X, Y, lr=0.01, verbose=False):
        Y = self.map_y_to_minus_one_plus_one(Y)

        if self._use_bias:
            X = np.concatenate([X, np.ones((X.shape[0], 1))], axis=-1)

        n, d = X.shape
        self._w = np.zeros(d)
        t = 0  # global step counter for adaptive lr

        for epoch in range(self._n_epochs):
            indices = np.random.permutation(n)

            for i in indices:
                xi, yi = X[i], Y[i]
                lr = 1.0 / (self._lambda * t)
                margin = yi * (xi @ self._w)    

                if margin >= 1:
                    grad = self._lambda * self._w
                else:
                    grad = self._lambda * self._w - yi * xi

                self._w -= lr * grad
                t += 1

            if verbose:
                scores = X @ self._w
                print(f"Epoch {epoch+1}/{self._n_epochs} - Loss: {self.loss(Y, scores):.4f}")

    def predict(self, X):
        if self._use_bias:
            X = np.concatenate([X, np.ones((X.shape[0], 1))], axis=-1)
        return self.map_y_to_original_values(np.sign(X @ self._w))