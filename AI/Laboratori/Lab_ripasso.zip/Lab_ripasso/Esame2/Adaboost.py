import numpy as np

class WeakClassifier:

    def __init__(self):
        self._dim = None
        self._threshold = None
        self._label_above_split = None

    def fit(self, X, Y):
        n, d = X.shape
        possible_labels = np.unique(Y)
        self._dim = np.random.choice(d)
        self._threshold = np.random.uniform(
            low=np.min(X[:, self._dim]),
            high=np.max(X[:, self._dim])
        )
        self._label_above_split = np.random.choice(possible_labels)

    def predict(self, X):
        y_pred = np.ones(X.shape[0]) * self._label_above_split
        y_pred[X[:, self._dim] < self._threshold] = -self._label_above_split
        return y_pred


class AdaBoostClassifier:

    def __init__(self, n_learners):
        self.n_learners = n_learners
        self.learners = []
        self.alphas = np.zeros(n_learners)

    def fit(self, X, Y):
        n, d = X.shape
        sample_weights = np.ones(n) / n
        for l in range(self.n_learners):
            sampled_indices = np.random.choice(n, size=n//2, p=sample_weights)
            X_sampled = X[sampled_indices]
            error = 1
            while error > 0.5:
                learner = WeakClassifier()
                learner.fit(X_sampled, Y[sampled_indices])
                y_pred = learner.predict(X_sampled)
                error = np.sum(sample_weights[sampled_indices] * (y_pred != Y[sampled_indices]))/np.sum(sample_weights[sampled_indices])
            y_pred = learner.predict(X_sampled)
            error = np.sum(sample_weights[sampled_indices] * (y_pred != Y[sampled_indices]))/ np.sum(sample_weights[sampled_indices])
            if error == 0:
                alpha = 1e10 
            else:
                alpha = 0.5 * np.log((1 - error) / (error + 1e-10)) 
            sample_weights *= np.exp(-alpha * Y * y_pred)
            sample_weights /= np.sum(sample_weights)

    def predict(self, X):
        y_pred = np.zeros(X.shape[0])
        for alpha, learner in zip(self.alphas, self.learners):
            y_pred += alpha * learner.predict(X)
        return np.sign(y_pred)