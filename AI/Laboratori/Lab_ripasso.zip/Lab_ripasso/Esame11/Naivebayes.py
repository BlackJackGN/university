import numpy as np

class NaiveBayesClassifier:

    def __init__(self):
        self._classes = None
        self._class_priors = None
        self._log_probs = None      # log P(x=1 | c), shape (n_classes, n_features)
        self._log_1m_probs = None   # log P(x=0 | c), shape (n_classes, n_features)

    def fit(self, X, Y):
        self._classes = np.unique(Y)
        n_samples = X.shape[0]
        X_flat = X.reshape(n_samples, -1)

        # class_mask: (n_samples, n_classes)
        class_mask = (Y[:, None] == self._classes[None, :])
        class_counts = class_mask.sum(axis=0)           # (n_classes,)
        self._class_priors = class_counts / n_samples

        # feature_counts: (n_classes, n_features) — vettorizzato, niente loop
        feature_counts = class_mask.T.astype(X_flat.dtype) @ X_flat
        probs = (feature_counts + 1) / (class_counts[:, None] + 2)  # Laplace smoothing
        self._log_probs = np.log(probs)
        self._log_1m_probs = np.log1p(-probs)           # log(1-p), più stabile di log(1-probs)

    def predict(self, X):
        X_flat = X.reshape(X.shape[0], -1)
        # matmul invece di broadcast (n_test,1,n_feat): niente tensore intermedio
        log_lik = X_flat @ self._log_probs.T + (1 - X_flat) @ self._log_1m_probs.T
        return self._classes[np.argmax(log_lik + np.log(self._class_priors), axis=1)]