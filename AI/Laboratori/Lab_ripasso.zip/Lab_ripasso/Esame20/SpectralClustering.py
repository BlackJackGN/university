import numpy as np
from sklearn.cluster import KMeans


def spectral_clustering(data, n_cl, sigma=1., fiedler_solution=False):
    # Gaussian similarity matrix (no self-loops)
    diff = data[:, np.newaxis] - data[np.newaxis, :]  # (n, n, d)
    W = np.exp(-sigma * np.sum(diff ** 2, axis=2))
    np.fill_diagonal(W, 0.)

    # Unnormalized Laplacian L = D - W
    D = np.diag(W.sum(axis=1))
    L = D - W

    # Eigendecomposition — eigh returns eigenvalues in ascending order
    _, eigvecs = np.linalg.eigh(L)

    if fiedler_solution:
        # Binary partition by sign of the Fiedler vector (2nd smallest eigenvector)
        return eigvecs[:, 1:n_cl+1] > 0

    # Spectral embedding: skip trivial zero eigenvalue, take next n_cl eigenvectors
    X = eigvecs[:, 1:n_cl + 1]
    return KMeans(n_clusters=n_cl, n_init=10).fit_predict(X)
