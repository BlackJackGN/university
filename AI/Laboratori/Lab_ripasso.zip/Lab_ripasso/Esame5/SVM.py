import numpy as np
from numpy.linalg import norm

def compute_kernel_matrix(X1, X2, kernel_func, **kwargs):
    if kernel_func == 'linear':
        return X1 @ X2.T
    elif kernel_func == 'rbf':
        gamma = kwargs.get('gamma', 0.01)
        X1_sq = np.sum(X1**2, axis=1, keepdims=True)
        X2_sq = np.sum(X2**2, axis=1, keepdims=True)
        sq_dists = X1_sq + X2_sq.T - 2 * (X1 @ X2.T)
        return np.exp(-gamma * sq_dists)

class SVM:

    def __init__(self, n_epochs, lambDa):
        self._n_epochs = n_epochs
        self._lambda = lambDa
        self._alpha = None
        self._X_train = None
        self._Y_train = None
        self._kernel_func = None

    def map_y_to_minus_one_plus_one(self, y):
        ynew = np.array(y, dtype=float)
        labels = np.unique(ynew)
        ynew[ynew == labels[0]] = -1.0
        ynew[ynew == labels[1]] = 1.0
        return ynew

    def fit_kernel(self, X, Y, kernel_func, verbose=False):
        n_samples = X.shape[0]
        Y = self.map_y_to_minus_one_plus_one(Y)
        self._Y_train = Y
        self._X_train = X
        self._kernel_func = kernel_func
        self._alpha = np.zeros(n_samples)
        K = compute_kernel_matrix(X, X, kernel_func)

        t=0
        for epoch in range(self._n_epochs):
            index=np.random.permutation(n_samples)
            for i in index:     
                t += 1
                eta = 1.0 / (self._lambda * t)
                score = np.sum(self._alpha * self._Y_train * K[:, i])
                self._alpha *= (1 - eta * self._lambda) 
                if self._Y_train[i] * score <= 1:
                    self._alpha[i] += eta * self._Y_train[i]

    def predict_kernel(self, X):
        K_test = compute_kernel_matrix(X, self._X_train, self._kernel_func)
        scores = K_test @ (self._alpha * self._Y_train)
        return np.sign(scores)