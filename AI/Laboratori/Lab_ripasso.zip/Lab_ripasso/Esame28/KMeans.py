import numpy as np

class KMeans:

    def __init__(self, n_cl, n_init=1):
        self.n_cl = n_cl
        self.n_init = n_init

    def _init_centers(self, X):
        n_samples, dim = X.shape
        centers = np.zeros((self.n_cl, dim))
        for i in range(dim):
            centers[:, i] = np.random.uniform(
                low=np.min(X[:, i]),
                high=np.max(X[:, i]),
                size=self.n_cl
            )
        return centers

    def single_fit_predict(self, X):
        n_samples, dim = X.shape
        centers = self._init_centers(X)
        old_assignments = np.zeros(n_samples)
        while True:
            distances = np.linalg.norm(X[:, np.newaxis, :] - centers[np.newaxis, :, :], axis=2)
            assignments = np.argmin(distances, axis=1)

            centers = np.array([X[assignments == k].mean(axis=0) for k in range(self.n_cl)])
            if np.array_equal(assignments, old_assignments):
                break
            old_assignments = assignments
        return centers, assignments        

    def compute_cost_function(self, X, centers, assignments):
        return np.sum(np.linalg.norm(X - centers[assignments], axis=1)**2)

    def fit_predict(self, X):
        best_cost = np.inf
        best_assignments = None
        for _ in range(self.n_init):
            centers, assignments = self.single_fit_predict(X)
            cost = self.compute_cost_function(X, centers, assignments)
            if cost < best_cost:
                best_cost = cost
                best_assignments = assignments
        return best_assignments