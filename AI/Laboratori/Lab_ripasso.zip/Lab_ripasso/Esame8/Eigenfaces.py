import numpy as np

class Eigenfaces:

    def __init__(self, n_components):
        self.n_components = n_components
        self._x_mean = None
        self._ef = None

    def fit(self, X):
        self._x_mean = np.mean(X, axis=0)
        X_centered = X - self._x_mean
        # Dual trick: n×n instead of d×d (efficient when n << d)
        cov_small = (X_centered @ X_centered.T) / X.shape[0]
        eigenvalues, eigenvectors_small = np.linalg.eigh(cov_small)
        idx = np.argsort(eigenvalues)[::-1][:self.n_components]
        eigenvectors_small = eigenvectors_small[:, idx]
        # Recover d-dimensional eigenvectors and normalize
        ef = X_centered.T @ eigenvectors_small
        self._ef = ef / np.linalg.norm(ef, axis=0)

    def transform(self, X):
        return (X - self._x_mean) @ self._ef

    def inverse_transform(self, X):
        return X @ self._ef.T + self._x_mean