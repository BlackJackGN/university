import numpy as np

eps = np.finfo(float).eps

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def loss(y_true, y_pred):
    y_pred = np.clip(y_pred, eps, 1 - eps)
    return -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))

def dloss_dw(y_true, y_pred, X):
    return X.T @ (y_pred - y_true) / len(y_true)

class LogisticRegression:

    def __init__(self):
        self.w = None

    def fit_gd(self, X, Y, n_epochs, learning_rate, verbose=False):
        n_samples, n_features = X.shape
        X_b = np.concatenate([X, np.ones((n_samples, 1))], axis=1)
        self.w = np.random.randn(n_features + 1) * 0.001

        for epoch in range(n_epochs):
            y_pred = sigmoid(X_b @ self.w)
            grad = dloss_dw(Y, y_pred, X_b)
            self.w -= learning_rate * grad
            if verbose:
                print(f"Epoch {epoch+1}/{n_epochs}, loss: {loss(Y, y_pred):.4f}")

    def predict(self, X):
        X = np.concatenate([X, np.ones((X.shape[0], 1))], axis=1)
        return (sigmoid(X @ self.w) >= 0.5).astype(int)