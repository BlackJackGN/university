import numpy as np

class NaiveBayesClassifier:

    def __init__(self):
        self._classes = None
        self._eps = np.finfo(np.float32).eps
        self._class_priors = None
        self._pixel_probs_given_class = None

    def fit(self, X, Y):
        X_flat = X.reshape(X.shape[0], -1)
        classes, counts = np.unique(Y, return_counts=True)
        self._classes = classes
        self._class_priors = counts / len(Y)
        self._pixel_probs_given_class = np.array([np.mean(X_flat[Y == c], axis=0) for c in classes])

    def predict(self, X):
        if X.ndim == 3:
            X_flat = X.reshape(X.shape[0], -1)
        else:
            X_flat = X
        
        log_priors = np.log(self._class_priors + self._eps)
        log_likelihoods = np.sum(X_flat[:, np.newaxis, :] * np.log(self._pixel_probs_given_class + self._eps) + (1 - X_flat[:, np.newaxis, :]) * np.log(1 - self._pixel_probs_given_class + self._eps), axis=2)
        log_posteriors = log_priors + log_likelihoods
        return self._classes[np.argmax(log_posteriors, axis=1)]