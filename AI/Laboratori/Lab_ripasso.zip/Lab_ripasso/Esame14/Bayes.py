import numpy as np

class NaiveBayesClassifier:

    def __init__(self):
        self._classes = None
        self._eps = np.finfo(np.float32).eps
        self._class_priors = None
        self._pixel_probs_given_class = None

    def fit(self, X, Y):
        X = X.reshape(X.shape[0], -1)    # (N, 28, 28) → (N, 784)
    
        self._classes = np.unique(Y)
        n_samples = X.shape[0]
        n_classes = len(self._classes)
        n_features = X.shape[1]

        # Compute class priors
        self._class_priors = np.array([np.sum(Y == c) / n_samples for c in self._classes])

        # Compute pixel probabilities given each class
        self._pixel_probs_given_class = np.zeros((n_classes, n_features))
        for i, c in enumerate(self._classes):
            X_c = X[Y == c]
            # Add Laplace smoothing
            self._pixel_probs_given_class[i] = (np.sum(X_c, axis=0) + self._eps) / (X_c.shape[0] + 2 * self._eps)

    def predict(self, X):
        X = X.reshape(X.shape[0], -1) 
        # Compute log-likelihood for each class
        log_likelihoods = np.zeros((X.shape[0], len(self._classes)))
        for i, c in enumerate(self._classes):
            log_likelihoods[:, i] = np.log(self._class_priors[i]) + np.sum(X * np.log(self._pixel_probs_given_class[i]) + (1 - X) * np.log(1 - self._pixel_probs_given_class[i]), axis=1)

        # Predict the class with the highest log-likelihood
        return self._classes[np.argmax(log_likelihoods, axis=1)]