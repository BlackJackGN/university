import numpy as np

class NaiveBayesClassifier:

    def __init__(self):
        self._classes = None
        self._eps = np.finfo(np.float32).eps
        self._class_priors = None
        self._pixel_probs_given_class = None

    def fit(self, X, Y):
        n_samples = X.shape[0]
        X = X.reshape(X.shape[0], -1)

        self._classes = np.unique(Y)

        # mask: (n_classes, n_samples)
        mask = (Y[np.newaxis, :] == self._classes[:, np.newaxis]).astype(np.float64)
        counts = mask.sum(axis=1)  # (n_classes,)

        self._class_priors = counts / n_samples

        # P(x_i=1 | c) with Laplace smoothing — shape: (n_classes, n_features)
        self._pixel_probs_given_class = np.array([np.mean(X[Y == c], axis=0) for c in self._classes])

    def predict(self, X):
        n_samples = X.shape[0]
        X = X.reshape(X.shape[0], -1)
        p = self._pixel_probs_given_class   # (n_classes, n_features)

        # log-likelihood: x·log(p) + (1-x)·log(1-p) — shape: (n_samples, n_classes)
        log_likelihood = X @ np.log(p+self._eps).T + (1 - X) @ np.log(1 - p+self._eps).T

        log_posteriors = np.log(self._class_priors) + log_likelihood
        return self._classes[np.argmax(log_posteriors, axis=1)]
