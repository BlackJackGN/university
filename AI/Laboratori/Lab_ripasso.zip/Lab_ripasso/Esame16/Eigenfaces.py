import numpy as np

class Eigenfaces:

    def __init__(self, n_components):
        self.n_components = n_components
        self._x_mean = None
        self._ef = None

    def fit(self, X):
        self._x_mean = X.mean(axis=0)
        X_centered = X - self._x_mean          # (m, N²)
        m = X_centered.shape[0]

        # Eigen trick: m×m instead of N²×N²
        L = X_centered @ X_centered.T / m   # (m, m)
        eigenvalues, eigenvectors = np.linalg.eigh(L)
        idx = np.argsort(eigenvalues)[::-1][:self.n_components]
        eigenvectors = eigenvectors[:, idx]         # (m, n_components)

        # Lift back to pixel space and normalize
        ef = X_centered.T @ eigenvectors            # (N², n_components)
        self._ef = ef / np.linalg.norm(ef, axis=0)
        return self

    def transform(self, X):
        return (X - self._x_mean) @ self._ef

    def inverse_transform(self, X):
        return X @ self._ef.T + self._x_mean