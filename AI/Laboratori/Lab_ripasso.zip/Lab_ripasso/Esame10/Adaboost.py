import numpy as np

class WeakClassifier:

    def __init__(self):
        self._dim = None
        self._threshold = None
        self._label_above_split = None

    def fit(self, X, Y):
        n, d = X.shape
        possible_labels = np.unique(Y)
        self._dim = np.random.choice(d)
        self._threshold = np.random.uniform(
            low=np.min(X[:, self._dim]),
            high=np.max(X[:, self._dim])
        )
        self._label_above_split = np.random.choice(possible_labels)

    def predict(self, X):
        n = X.shape[0]
        predictions = np.zeros(n)
        for i in range(n):
            if X[i, self._dim] > self._threshold:
                predictions[i] = self._label_above_split
            else:
                predictions[i] = -self._label_above_split
        return predictions


class AdaBoostClassifier:

    def __init__(self, n_learners):
        self.n_learners = n_learners
        self.learners = []
        self.alphas = np.zeros(n_learners)

    def fit(self, X, Y):
        n = X.shape[0]
        # Inizializza i pesi
        weights = np.ones(n) / n

        for m in range(self.n_learners):
            # Crea un weak learner
            learner = WeakClassifier()
            learner.fit(X, Y)

            # Calcola le predizioni del weak learner
            predictions = learner.predict(X)

            # Calcola l'errore ponderato
            error = np.sum(weights * (predictions != Y)) / np.sum(weights)

            # Calcola l'alpha
            self.alphas[m] = 0.5 * np.log((1 - error) / (error + 1e-10))

            # Aggiorna i pesi
            weights *= np.exp(-self.alphas[m] * Y * predictions)
            weights /= np.sum(weights)

            # Salva il weak learner
            self.learners.append(learner)

    def predict(self, X):
        n = X.shape[0]
        final_predictions = np.zeros(n)
        for m in range(self.n_learners):
            predictions = self.learners[m].predict(X)
            final_predictions += self.alphas[m] * predictions
        return np.sign(final_predictions)