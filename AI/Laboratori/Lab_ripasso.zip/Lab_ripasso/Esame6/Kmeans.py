import numpy as np

class KMeans:

    def __init__(self, n_cl, n_init=1):
        self.n_cl = n_cl
        self.n_init = n_init

    def single_fit_predict(self, X):
        n_samples, dim = X.shape
        centers = self._init_centers(X)
        old_assignments = np.zeros(n_samples)
        while True:
            new_assignments = np.linalg.norm(
                X[:, np.newaxis, :] - centers, axis=2
            ).argmin(axis=1)
            centers = np.array([
                X[new_assignments == k].mean(axis=0)
                for k in range(self.n_cl)
            ])
            if np.array_equal(old_assignments, new_assignments):
                break
            old_assignments = new_assignments
        return centers, new_assignments

    def compute_cost_function(self, X, centers, assignments):
        return np.sum(np.linalg.norm(X - centers[assignments], axis=1)**2)
    
    def _init_centers(self, X):
        idx = np.random.choice(X.shape[0], self.n_cl, replace=False)
        return X[idx]

    def fit_predict(self, X):
        best_cost = np.inf
        best_centers = None
        best_assignments = None
        for _ in range(self.n_init):
            centers, assignments = self.single_fit_predict(X)
            cost = self.compute_cost_function(X, centers, assignments)
            if cost < best_cost:
                best_cost = cost
                best_centers = centers
                best_assignments = assignments
        return best_centers, best_assignments