import numpy as np
from sklearn.cluster import KMeans

def spectral_clustering(data, n_cl, sigma=1., fiedler_solution=False):
    # Compute the similarity matrix
    S = np.exp(-np.square(np.linalg.norm(data[:, np.newaxis] - data, axis=2)) / (2 * sigma ** 2))
    np.fill_diagonal(S, 0)
    
    # Compute the degree matrix
    D = np.diag(S.sum(axis=1))

    # Compute the unnormalized Laplacian
    L = D - S

    # Compute the eigenvalues and eigenvectors of the Laplacian
    eigvals, eigvecs = np.linalg.eigh(L)

    # Sort the eigenvalues and corresponding eigenvectors
    idx = np.argsort(eigvals)
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]

    if fiedler_solution:
        return eigvecs[:, 1:n_cl+1] > 0

    return KMeans(n_clusters=n_cl, n_init=10).fit_predict(eigvecs[:, 1:n_cl+1])