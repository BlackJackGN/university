import numpy as np

class SVM:

    def __init__(self, n_epochs, lambDa, use_bias=True):
        self._n_epochs = n_epochs
        self._lambda = lambDa
        self._use_bias = use_bias
        self._w = None
        self._original_labels = None

    def map_y_to_minus_one_plus_one(self, y):
        ynew = np.array(y, dtype=float)
        self._original_labels = np.unique(ynew)
        ynew[ynew == self._original_labels[0]] = -1.0
        ynew[ynew == self._original_labels[1]] = 1.0
        return ynew

    def map_y_to_original_values(self, y):
        ynew = np.array(y, dtype=float)
        ynew[ynew == -1.0] = self._original_labels[0]
        ynew[ynew == 1.0] = self._original_labels[1]
        return ynew

    def loss(self, y_true, y_pred):
        # hinge loss media + regolarizzazione L2
        hinge = np.maximum(0.0, 1.0 - y_true * y_pred)
        return (self._lambda / 2.0) * np.dot(self._w, self._w) + np.mean(hinge)

    def fit_gd(self, X, Y, verbose=False):
        X = np.array(X, dtype=float)
        if self._use_bias:
            # integra il bias come colonna di 1: b = ultima componente di w
            X = np.hstack([X, np.ones((X.shape[0], 1))])
        y = self.map_y_to_minus_one_plus_one(Y)
        n_samples, n_features = X.shape

        self._w = np.zeros(n_features)
        rng = np.random.default_rng()
        t = 0
        for epoch in range(self._n_epochs):
            for _ in range(n_samples):
                t += 1
                i = rng.integers(n_samples)
                eta = 1.0 / (self._lambda * t)
                if y[i] * np.dot(self._w, X[i]) < 1.0:
                    self._w = (1.0 - eta * self._lambda) * self._w + eta * y[i] * X[i]
                else:
                    self._w = (1.0 - eta * self._lambda) * self._w
            if verbose:
                print(f"epoch {epoch + 1}/{self._n_epochs} - loss: {self.loss(y, X @ self._w):.6f}")
        return self

    def predict(self, X):
        X = np.array(X, dtype=float)
        if self._use_bias:
            X = np.hstack([X, np.ones((X.shape[0], 1))])
        y_pred = np.where(X @ self._w >= 0.0, 1.0, -1.0)
        return self.map_y_to_original_values(y_pred)