import numpy as np

class NaiveBayesClassifier:

    def __init__(self):
        self._classes = None
        self._eps = np.finfo(np.float32).eps
        self._class_priors = None
        self._pixel_probs_given_class = None

    def fit(self, X, Y):
        n_samples = X.shape[0]
        self._classes = np.unique(Y)

        self._class_priors = np.array([np.sum(Y == c) / n_samples for c in self._classes])
        self._pixel_probs_given_class = np.array([X[Y == c].mean(axis=0) for c in self._classes])

    def predict(self, X, returnpred=False):
        n_samples = X.shape[0]
        n_classes = len(self._classes)

        X_flat = X.reshape(n_samples, -1)
        probs = self._pixel_probs_given_class.reshape(n_classes, -1)

        log_priors = np.log(self._class_priors + self._eps)
        log_likelihoods = (X_flat @ np.log(probs + self._eps).T + (1 - X_flat) @ np.log(1 - probs + self._eps).T)

        log_posteriors = log_priors + log_likelihoods

        predictions = self._classes[np.argmax(log_posteriors, axis=1)]

        if returnpred:
            return predictions, log_posteriors
        return predictions
