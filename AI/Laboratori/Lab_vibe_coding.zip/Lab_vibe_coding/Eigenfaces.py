import numpy as np

class Eigenfaces:

    def __init__(self, n_components):
        self.n_components = n_components
        self._x_mean = None
        self._ef = None

    def fit(self, X):
        self._x_mean = X.mean(axis=0)
        A = X - self._x_mean
        L = A @ A.T
        eigenvalues, eigenvectors = np.linalg.eigh(L)
        idx = np.argsort(eigenvalues)[::-1]
        eigenvectors = eigenvectors[:, idx]
        U = A.T @ eigenvectors                     
        norms = np.linalg.norm(U, axis=0, keepdims=True)
        U = U / norms                              
        self._ef = U[:, :self.n_components]        

    def transform(self, X):
        return (X - self._x_mean) @ self._ef

    def inverse_transform(self, X):
        return X @ self._ef.T + self._x_mean