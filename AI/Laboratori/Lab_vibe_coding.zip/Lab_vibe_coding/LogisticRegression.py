import numpy as np

eps = np.finfo(float).eps

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def loss(y_true, y_pred):
    return -np.mean(y_true * np.log(y_pred + eps) + (1 - y_true) * np.log(1 - y_pred + eps))

def dloss_dw(y_true, y_pred, X):
    n_samples = X.shape[0]
    return X.T @ (y_pred - y_true) / n_samples

class LogisticRegression:

    def __init__(self):
        self.w = None

    def fit_gd(self, X, Y, n_epochs, learning_rate, verbose=False):
        n_features = X.shape[1]

        self.w = np.random.randn(n_features) * 0.001

        for e in range(n_epochs):
            y_pred = sigmoid(X @ self.w)

            if verbose:
                print(f'Epoch {e:4d} - loss: {loss(Y, y_pred):.6f}')

            self.w -= learning_rate * dloss_dw(Y, y_pred, X)

    def predict(self, X):
        return np.round(sigmoid(X @ self.w))
