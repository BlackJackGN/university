import numpy as np
from sklearn.cluster import KMeans


def spectral_clustering(data, n_cl, sigma=1., fiedler_solution=False):
    W = np.exp(-np.linalg.norm(data[:, None, :] - data[None, :, :], axis=2) ** 2 / (sigma ** 2))
    np.fill_diagonal(W, 0.0)
    D = np.diag(W.sum(axis=1))
    L = D - W
    _, eigvecs = np.linalg.eigh(L)
    if fiedler_solution:
        return eigvecs[:, 1:n_cl+1]>0
    else:
        return KMeans(n_clusters=n_cl, n_init=10).fit_predict(eigvecs[:, 1:n_cl+1])