import numpy as np

class WeakClassifier:

    def __init__(self):
        self._dim = None
        self._threshold = None
        self._label_above_split = None

    def fit(self, X, Y):
        # campiona una feature a caso e una soglia uniforme nel suo range
        self._dim = np.random.randint(X.shape[1])
        feature = X[:, self._dim]
        self._threshold = np.random.uniform(feature.min(), feature.max())
        self._label_above_split = np.random.choice([-1, 1])

    def predict(self, X):
        Y_pred = np.where(X[:, self._dim] > self._threshold,self._label_above_split,-self._label_above_split)
        return Y_pred


class AdaBoostClassifier:

    def __init__(self, n_learners):
        self.n_learners = n_learners
        self.learners = []
        self.alphas = np.zeros(n_learners)

    def fit(self, X, Y):
        n = X.shape[0]
        sample_weights = np.ones(n) / n

        for i in range(self.n_learners):
            error = 1
            while error > 0.5:
                learner = WeakClassifier()
                # campiona n//2 punti secondo i pesi correnti
                subset = np.random.choice(n, n // 2, replace=False, p=sample_weights)
                learner.fit(X[subset], Y[subset])
                # errore pesato e normalizzato calcolato solo sul subset
                Y_pred = learner.predict(X[subset])
                error = np.sum(sample_weights[subset] * (Y_pred != Y[subset])) \
                        / np.sum(sample_weights[subset])

            alpha = 0.5 * np.log((1 - error) / (error + 1e-10))
            self.learners.append(learner)
            self.alphas[i] = alpha

            # aggiorna i pesi su tutto il dataset e rinormalizza
            Y_pred_all = learner.predict(X)
            sample_weights *= np.exp(-alpha * Y * Y_pred_all)
            sample_weights /= np.sum(sample_weights)

    def predict(self, X):
        scores = np.zeros(X.shape[0])
        for alpha, learner in zip(self.alphas, self.learners):
            scores += alpha * learner.predict(X)
        return np.sign(scores)
